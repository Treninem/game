
	This is an OBJ pack of the landscape blocks, designed for use with Asset Forge. ( https://assetforge.io )
	
	You can load these models directly in to a game engine, however it is recommended to combine
	these in an external modeler such as Asset Forge to help on optimization. 
	
	To load into Asset Forge:
		- Place the 'Nature Landscape' folder inside 'Collections' folder of Asset Forge (AssetForge\Collections).
		- Reload Asset Forge to load in the new models.
	
	Known issues:
		* Some vertices may not match up correctly. To solve this:
			In Blender: Use the 'Remove Doubles' function.
			In Lightwave: Use the 'Merge Points' function.
			In Maya: Use the 'Edit Mesh > Merge' function.
			Ensure that the threshold is appropriate, or that you have selected only misaligned vertices. 
			
		* Slight misalignment on mountain pieces when intersecting with water pieces, 
		  causing a gap between water and mountain pieces. To solve this:
			Add an extra mountain piece directly below the piece causing the issue, and this will fill any gaps.
			
		* Asset Forge does not group materials together when exporting to an FBX. This removes a lot of optimization,
		  and I can't find a decent way to fix this. For now, I recommend exporting to OBJ and modifying the material
		  properties within your game engine.
		  
	Notes:
		- The 'nature_landscape.mtl' file contains all of the original materials.
		  If you aren't changing the materials inside Asset Forge, this can be used
		  directly in your game engine.
		  
	Author:
		- Nat from Nateonus Apps ( https://twitter.com/nateonus )
		
	Special Thanks:
		- Kenney, for creating brilliant landscape assets! ( https://www.kenney.nl )
		
	License: 
		- Creative Commons Zero, CC0
		
		
		
		
		
--- Original Kenney License ---
	
	Nature Kit (1.0)

	Created/distributed by Kenney (www.kenney.nl)

			------------------------------

	License: (Creative Commons Zero, CC0)
	http://creativecommons.org/publicdomain/zero/1.0/

	This content is free to use in personal, educational and commercial projects.

	Support us by crediting (Kenney or www.kenney.nl), this is not mandatory.

			------------------------------

	Donate:   http://support.kenney.nl
	Request:  http://request.kenney.nl
	Patreon:  http://patreon.com/kenney/

	Follow on Twitter for updates:
	@KenneyNL